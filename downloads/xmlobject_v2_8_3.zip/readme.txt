********************************

	XMLObject() Readme File
	
  �2001, 2002 Chriztian Steinmeier

********************************

The main documentation for this object is available at the following URL:

		http://www.greystate.dk/xmlobject/

- please refer to this when in doubt, or if you need some examples to get you started.

Along with this "readme.txt" you should have the following 3 files:

	1. "xmlobject.asp"		- The main code file.
	2. "xmlobj_constants.asp"	- Constants used in the main file.
	3. "xmlobj_resources.asp"	- Some resource strings, mainly errormessages.
	
All 3 files should be placed in the same directory, and you will only need to refer to the main file (xmlobject.asp) in your code, as this file includes the others as needed.

Hopefully you will find lots of uses for this little object - feel free to use it everywhere, but don't blame me for anything that would happen as a result of your use of XMLObject()... it's free, but not guaranteed to be perfect (what is, anyway?).

Please don't hesistate to drop me any comments you might have, whether it'd be bugs, features, wishes or thank-you's - they are welcome. Send mail to xmlobject@greystate.dk and I'll get back to you ASAP.

Enjoy!

Chriztian Steinmeier,
Greystate Web Division
2002.

